package carpet.mixins;
import net.minecraft.client.model.monster.shulker.ShulkerModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(net.minecraft.client.renderer.blockentity.ShulkerBoxRenderer.class)
public interface ShulkerBoxAccessMixin {
    @Accessor("model")
    ShulkerModel getModel();
}