package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1766;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.Tool;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1810.class)
public class PickaxeItem_missingToolsMixin extends class_1766
{

    protected PickaxeItem_missingToolsMixin(class_1832 material, TagKey<Block> tag, class_1793 settings) {
        super(material, tag, settings);
    }

    @Override
    public float method_58404(ItemStack stack, BlockState state) {
        if (CarpetSettings.missingTools && state.getSoundType() == SoundType.GLASS)
        {
            final Tool tool = stack.method_57824(DataComponents.TOOL);
            return tool != null ? tool.getMiningSpeed(Blocks.STONE.defaultBlockState()) : super.method_58404(stack, state);
        }
        return super.method_58404(stack, state);
    }
}
